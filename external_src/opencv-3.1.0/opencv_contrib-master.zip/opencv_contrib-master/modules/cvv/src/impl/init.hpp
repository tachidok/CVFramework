#ifndef CVVISUAL_INIT_HPP
#define CVVISUAL_INIT_HPP

namespace cvv
{
namespace impl
{
/**
 * @brief Initializes filters and views.
 */
void initializeFilterAndViews();
}
}
#endif // CVVISUAL_INIT_HPP
